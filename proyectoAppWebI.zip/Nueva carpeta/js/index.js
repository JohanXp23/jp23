// index.js

// Obtener elementos del DOM
const navMenu = document.querySelector('.nav__link--menu');
const navToggle = document.querySelector('.nav__menu');
const navClose = document.querySelector('.nav__close');

// Función para abrir el menú
function openNav() {
    navMenu.classList.add('nav__link--show');
}

// Función para cerrar el menú
function closeNav() {
    navMenu.classList.remove('nav__link--show');
}

// Agregar eventos de clic a los botones de menú
navToggle.addEventListener('click', openNav);
navClose.addEventListener('click', closeNav);
